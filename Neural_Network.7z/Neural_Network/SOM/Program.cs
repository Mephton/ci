﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SOM {
	class Program {
		static void Main(string[] args) {
			Visualizer vs = new Visualizer();
			vs.ShowDialog();
		}
	}
}
