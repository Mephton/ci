﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neural_Network
{
    class Vector
    {
        List<decimal> _values = new List<decimal>();
        public Vector(decimal v)
        {
            _values.Add(v);
        }


    }
}
